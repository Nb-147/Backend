import cartService from '../services/cartsServices.js';

const getCartById = async (req, res) => {
    const { cid } = req.params;

    try {
        const products = await cartService.getCartById(cid);
        res.status(200).json(products);
    } catch (error) {
        console.error('Error fetching cart products:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

const getUserCart = async (req, res) => {
    try {
        const cartId = req.user.cart;
        const products = await cartService.getUserCart(cartId);
        res.status(200).json(products);
    } catch (error) {
        console.error('Error fetching cart products:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

const updateAllCart = async (req, res) => {
    const { cid } = req.params;
    const products = req.body;

    try {
        const updatedCart = await cartService.updateAllCart(cid, products);
        res.status(200).json({ message: 'Cart updated successfully' });
    } catch (error) {
        console.error('Error updating cart:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

const updateProductQuantity = async (req, res) => {
    const { cid, pid } = req.params;
    const { quantity } = req.body;

    try {
        await cartService.updateProductQuantity(cid, pid, quantity);
        res.status(200).json({ message: 'Product quantity updated successfully' });
    } catch (error) {
        console.error('Error updating product quantity:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

const createCart = async (req, res) => {
    try {
        const cart = await cartService.createCart();
        res.status(201).json({ message: 'Cart created', cart });
    } catch (error) {
        console.error('Error creating cart:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

const addProductToCart = async (req, res) => {
    const { cid, pid } = req.params;
    const userCart = req.user.cart;

    try {
        const updatedCart = await cartService.addProductToCart(cid, pid, userCart);
        res.status(200).json({ message: 'Product added to cart successfully', updatedCart });
    } catch (error) {
        console.error('Error adding product to cart:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

const deleteProductFromCart = async (req, res) => {
    const { cartId, productId } = req.params;
    const userCart = req.user.cart;

    try {
        const updatedCart = await cartService.deleteProductFromCart(cartId, productId, userCart);
        res.status(200).json({ message: 'Product removed from cart successfully' });
    } catch (error) {
        console.error('Error removing product from cart:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

const deleteAllProducts = async (req, res) => {
    const userCart = req.user.cart;

    try {
        await cartService.deleteAllProducts(userCart);
        res.status(200).json({ message: 'All products have been removed from the cart' });
    } catch (error) {
        console.error('Error removing all products from cart:', error.message);
        res.status(500).json({
            error: 'Server error',
            detail: error.message,
        });
    }
};

export default {
    getCartById,
    getUserCart,
    updateAllCart,
    updateProductQuantity,
    createCart,
    addProductToCart,
    deleteProductFromCart,
    deleteAllProducts,
};