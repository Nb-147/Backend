export const config = {
    MONGO_URL: "mongodb+srv://Nico:49809075@cluster0.kqthm.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    DB_NAME: "Storage",
    PORT: 8080,
    JWT_SECRET: "StorageBruno123"
}